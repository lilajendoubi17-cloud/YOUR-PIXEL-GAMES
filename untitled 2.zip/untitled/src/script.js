const viewport = document.getElementById("viewport");
const modeButton = document.getElementById("modeButton");
const modeText = document.getElementById("modeText");
const modeHelp = document.getElementById("modeHelp");
const dialogue = document.getElementById("dialogue");

let objectMode = false;
let currentLine = 0;
let typingTimer = null;
let hideTimer = null;
let typingToken = 0;

const messages = [
  "J’ai passé une très bonne journée.",
  "Je suis heureuse de te voir.",
  "La nuit est le meilleur moment de la journée, tu trouves pas ?",
  "Nous deux, on forme une très bonne équipe.",
  "C’est super de se revoir."
];

function updateMode(){
  modeButton.textContent = objectMode ? "✕" : "🪑";
  modeText.textContent = objectMode ? "Mode objets 🪑" : "Mode fille 👧";
  modeHelp.textContent = objectMode ? "Déplace les objets" : "Déplace la fille";
}
modeButton.addEventListener("click", () => {
  objectMode = !objectMode;
  updateMode();
  hideDialogue();
});

function hideDialogue(){
  typingToken++;
  clearInterval(typingTimer);
  clearTimeout(hideTimer);
  dialogue.classList.remove("show");
  dialogue.style.display = "none";
}

function sayNext(){
  hideDialogue();
  const token = typingToken;
  const message = messages[currentLine];
  currentLine = (currentLine + 1) % messages.length;
  dialogue.textContent = "";
  dialogue.style.display = "block";
  dialogue.classList.add("show");
  let index = 0;

  typingTimer = setInterval(() => {
    if(token !== typingToken) return;
    dialogue.textContent += message[index];
    index++;
    if(index >= message.length){
      clearInterval(typingTimer);
      hideTimer = setTimeout(hideDialogue, 2600);
    }
  }, 48);
}

document.querySelectorAll(".girl").forEach(girl => {
  let startX = 0, startY = 0, offsetX = 0, offsetY = 0, moved = false, dragging = false;

  girl.addEventListener("pointerdown", event => {
    if(objectMode) return;
    event.preventDefault();
    dragging = true;
    moved = false;
    startX = event.clientX;
    startY = event.clientY;
    offsetX = startX - girl.getBoundingClientRect().left;
    offsetY = startY - girl.getBoundingClientRect().top;
    girl.setPointerCapture(event.pointerId);
  });
girl.addEventListener("pointermove", event => {
  if (!dragging || objectMode) return;

  if (
    Math.abs(event.clientX - startX) > 5 ||
    Math.abs(event.clientY - startY) > 5
  ) {
    moved = true;
  }

  if (!moved) return;

  const room = girl.closest(".room");
  const rect = room.getBoundingClientRect();

  let x = event.clientX - rect.left - offsetX;
  let y = event.clientY - rect.top - offsetY;

  x = Math.max(0, Math.min(x, rect.width - girl.offsetWidth));
  y = Math.max(0, Math.min(y, rect.height - girl.offsetHeight));

  girl.style.left = x + "px";
  girl.style.top = y + "px";
});
  
    if(!dragging || objectMode) return;
    if(Math.abs(event.clientX-startX) > 5 || Math.abs(event.clientY-startY) > 5) moved = true;
    if(!moved) return;
    const room = girl.closest(".room");
    const rect = room.getBoundingClientRect();
    let x = event.clientX - rect.left - offsetX;
    let y = event.clientY - rect.top - offsetY;
    x = Math.max(0, Math.min(x, rect.width - girl.offsetWidth));
    y = Math.max(0, Math.min(y, rect.height - girl.offsetHeight));
    // Déplacement de la fille
girl.style.left = x + "px";
girl.style.top = y + "px";

// Passage à la pièce voisine
const edge = 25;
const rooms = [...document.querySelectorAll(".room")];
const currentRoom = rooms.indexOf(room);

if (x <= edge && currentRoom > 0) {
  const nextRoom = rooms[currentRoom - 1];
  viewport.scrollTo({
    left: nextRoom.offsetLeft,
    behavior: "smooth"
  });
  girl.style.left = (nextRoom.offsetWidth - girl.offsetWidth - 30) + "px";
  startX = event.clientX;
}

if (x >= rect.width - girl.offsetWidth - edge &&
    currentRoom < rooms.length - 1) {
  const nextRoom = rooms[currentRoom + 1];
  viewport.scrollTo({
    left: nextRoom.offsetLeft,
    behavior: "smooth"
  });
  girl.style.left = "30px";
  startX = event.clientX;
}
  });

  function finishGirl(){
    if(!dragging) return;
    dragging = false;
    if(!moved && !objectMode) sayNext();
  }
  girl.addEventListener("pointerup", finishGirl);
  girl.addEventListener("pointercancel", () => {dragging=false;});
});

document.querySelectorAll(".item").forEach(item => {
  let dragging = false, moved = false, startX = 0, startY = 0, offsetX = 0, offsetY = 0;

  item.addEventListener("pointerdown", event => {
    if(!objectMode) return;
    event.preventDefault();
    event.stopPropagation();
    dragging = true;
    moved = false;
    startX = event.clientX;
    startY = event.clientY;
    offsetX = startX - item.getBoundingClientRect().left;
    offsetY = startY - item.getBoundingClientRect().top;
    item.setPointerCapture(event.pointerId);
  });

  item.addEventListener("pointermove", event => {
    if(!dragging || !objectMode) return;
    event.stopPropagation();
    if(Math.abs(event.clientX-startX) > 4 || Math.abs(event.clientY-startY) > 4) moved = true;
    if(!moved) return;
    const room = item.closest(".room");
    const rect = room.getBoundingClientRect();
    let x = event.clientX - rect.left - offsetX;
    let y = event.clientY - rect.top - offsetY;
    x = Math.max(0, Math.min(x, rect.width - item.offsetWidth));
    y = Math.max(0, Math.min(y, rect.height - item.offsetHeight));
    item.style.left = x + "px";
    item.style.top = y + "px";
  });

  item.addEventListener("pointerup", () => {dragging = false;});
  item.addEventListener("pointercancel", () => {dragging = false;});
});

document.querySelectorAll(".dot").forEach(button => {
  button.addEventListener("click", () => {
    const index = Number(button.dataset.room);
    viewport.scrollTo({left: index * window.innerWidth, behavior:"smooth"});
 document.querySelectorAll(".dot").forEach(button => {
  button.addEventListener("click", () => {
    const index = Number(button.dataset.room);

    viewport.scrollTo({
      left: index * window.innerWidth,
      behavior: "smooth"
    });


    document.querySelectorAll(".dot").forEach(b => {
      b.classList.remove("active");
    });

    button.classList.add("active");
    hideDialogue();
  });
});

viewport.addEventListener("scroll", () => {
  const index = Math.round(viewport.scrollLeft / window.innerWidth);

  document.querySelectorAll(".dot").forEach((b, i) => {
    b.classList.toggle("active", i === index);
  });

  hideDialogue();
});

updateMode();   

    
  